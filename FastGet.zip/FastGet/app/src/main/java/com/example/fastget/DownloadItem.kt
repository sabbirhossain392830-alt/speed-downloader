package com.example.fastget

import java.util.Locale

enum class Status { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED }

data class DownloadItem(
    val id: Long,
    val url: String,
    val fileName: String = "",
    val total: Long = -1L,
    val downloaded: Long = 0L,
    val resumable: Boolean = false,
    val segDone: List<Long> = emptyList(),
    val status: Status = Status.QUEUED,
    val speed: Long = 0L,
    val error: String? = null,
    val publicSaved: Boolean = false,
)

fun fmtBytes(b: Long): String {
    if (b < 0) return "?"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024
        i++
    }
    return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, units[i])
}
