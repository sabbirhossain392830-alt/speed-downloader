package com.example.fastget

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLongArray

/**
 * Core download engine: multi-segment (parallel) downloads, pause/resume,
 * persistence across app restarts.
 */
object Downloader {
    private const val SEGMENTS = 4

    private lateinit var app: Context
    private lateinit var dir: File
    private lateinit var store: File

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items

    private val jobs = ConcurrentHashMap<Long, Job>()
    private val progress = ConcurrentHashMap<Long, AtomicLongArray>()

    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(app.filesDir, "downloads")
        dir.mkdirs()
        store = File(app.filesDir, "downloads.json")
        load()
    }

    // ---------------------------------------------------------------- public API

    fun add(url: String): Boolean {
        val u = url.trim()
        if (!(u.startsWith("http://") || u.startsWith("https://"))) return false
        val id = System.currentTimeMillis()
        _items.update { listOf(DownloadItem(id = id, url = u)) + it }
        start(id)
        return true
    }

    fun start(id: Long) {
        if (jobs[id]?.isActive == true) return
        update(id) { it.copy(status = Status.RUNNING, error = null, speed = 0) }
        ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        jobs[id] = scope.launch {
            try {
                run(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                update(id) {
                    it.copy(status = Status.FAILED, error = e.message ?: "Download failed", speed = 0)
                }
            } finally {
                save()
            }
        }
    }

    fun pause(id: Long) {
        scope.launch {
            jobs[id]?.cancelAndJoin()
            val p = progress[id]
            update(id) {
                if (it.status == Status.RUNNING) {
                    it.copy(
                        status = Status.PAUSED,
                        speed = 0,
                        downloaded = p?.let(::sum) ?: it.downloaded,
                        segDone = p?.let(::snap) ?: it.segDone,
                    )
                } else it
            }
            save()
        }
    }

    /** Removes the entry. Unfinished/private files are deleted too. */
    fun remove(id: Long) {
        scope.launch {
            jobs.remove(id)?.cancelAndJoin()
            val item = _items.value.firstOrNull { it.id == id } ?: return@launch
            if (item.fileName.isNotEmpty()) File(dir, item.fileName).delete()
            progress.remove(id)
            _items.update { list -> list.filter { it.id != id } }
            save()
        }
    }

    // ---------------------------------------------------------------- engine

    private suspend fun run(id: Long) {
        var item = _items.value.first { it.id == id }
        if (item.fileName.isEmpty()) {
            item = probe(item)
            update(id) { item }
        }
        val file = File(dir, item.fileName)
        val total = item.total

        if (item.resumable && total > 0) {
            val n = if (total < 1_000_000) 1 else SEGMENTS
            val chunk = total / n
            val ranges = List(n) { i ->
                val s = i * chunk
                val e = if (i == n - 1) total - 1 else s + chunk - 1
                s to e
            }
            val done = AtomicLongArray(n)
            if (file.exists()) {
                for (i in 0 until n) done.set(i, item.segDone.getOrElse(i) { 0L })
            }
            progress[id] = done

            RandomAccessFile(file, "rw").use { raf ->
                if (raf.length() != total) raf.setLength(total)
                val ch = raf.channel
                coroutineScope {
                    val ticker = launch { tick(id, done) }
                    ranges.mapIndexed { i, r ->
                        async { segment(item.url, ch, i, r.first, r.second, done) }
                    }.awaitAll()
                    ticker.cancel()
                }
            }
        } else {
            // Server doesn't support ranges (or size unknown): single stream, no resume.
            val done = AtomicLongArray(1)
            progress[id] = done
            val req = Request.Builder().url(item.url).build()
            coroutineScope {
                val ticker = launch { tick(id, done) }
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                    FileOutputStream(file).use { out ->
                        val src = r.body!!.byteStream()
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val n = src.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done.addAndGet(0, n.toLong())
                        }
                    }
                }
                ticker.cancel()
            }
        }

        val size = file.length()
        val saved = exportPublic(file)
        update(id) {
            it.copy(
                status = Status.COMPLETED,
                total = size,
                downloaded = size,
                speed = 0,
                segDone = emptyList(),
                publicSaved = saved,
            )
        }
    }

    private suspend fun segment(
        url: String,
        ch: FileChannel,
        i: Int,
        start: Long,
        end: Long,
        done: AtomicLongArray,
    ) {
        val from = start + done.get(i)
        if (from > end) return
        val req = Request.Builder().url(url).header("Range", "bytes=$from-$end").build()
        client.newCall(req).execute().use { r ->
            if (r.code != 206) throw IOException("Server did not honor range (HTTP ${r.code})")
            val src = r.body!!.byteStream()
            val buf = ByteArray(64 * 1024)
            var pos = from
            while (true) {
                currentCoroutineContext().ensureActive()
                val n = src.read(buf)
                if (n < 0) break
                val bb = ByteBuffer.wrap(buf, 0, n)
                while (bb.hasRemaining()) pos += ch.write(bb, pos)
                done.addAndGet(i, n.toLong())
            }
        }
        if (start + done.get(i) <= end) throw IOException("Connection closed early")
    }

    private suspend fun tick(id: Long, done: AtomicLongArray) {
        var last = sum(done)
        var n = 0
        while (true) {
            delay(500)
            val now = sum(done)
            val speed = (now - last) * 2
            last = now
            update(id) { it.copy(downloaded = now, speed = speed, segDone = snap(done)) }
            if (++n % 4 == 0) save()
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun probe(item: DownloadItem): DownloadItem {
        val req = Request.Builder().url(item.url).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val name = uniqueName(fileNameFrom(r, item.url))
            return if (r.code == 206) {
                val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1L
                item.copy(fileName = name, total = total, resumable = total > 0)
            } else {
                item.copy(fileName = name, total = r.body?.contentLength() ?: -1L, resumable = false)
            }
        }
    }

    private fun fileNameFrom(r: Response, url: String): String {
        val cd = r.header("Content-Disposition")
        val fromHeader = cd?.let {
            Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
                .find(it)?.groupValues?.get(1)
        }
        val raw = fromHeader
            ?: r.request.url.pathSegments.lastOrNull { it.isNotEmpty() }
            ?: "download"
        val decoded = runCatching { URLDecoder.decode(raw, "UTF-8") }.getOrDefault(raw)
        return decoded.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "download" }
    }

    private fun uniqueName(name: String): String {
        val used = _items.value.map { it.fileName }.toSet()
        if (name !in used && !File(dir, name).exists()) return name
        val base = name.substringBeforeLast('.', name)
        val ext = if ('.' in name) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (true) {
            val c = "$base ($n)$ext"
            if (c !in used && !File(dir, c).exists()) return c
            n++
        }
    }

    /** Moves the finished file into the public Downloads/FastGet folder (no permission needed). */
    private fun exportPublic(file: File): Boolean = runCatching {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FastGet")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = app.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            ?: return@runCatching false
        resolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        cv.clear()
        cv.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, cv, null, null)
        file.delete()
        true
    }.getOrDefault(false)

    private fun update(id: Long, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    private fun sum(a: AtomicLongArray): Long {
        var s = 0L
        for (i in 0 until a.length()) s += a.get(i)
        return s
    }

    private fun snap(a: AtomicLongArray): List<Long> = List(a.length()) { a.get(it) }

    @Synchronized
    private fun save() {
        runCatching {
            val arr = JSONArray()
            _items.value.forEach {
                arr.put(
                    JSONObject().apply {
                        put("id", it.id)
                        put("url", it.url)
                        put("name", it.fileName)
                        put("total", it.total)
                        put("done", it.downloaded)
                        put("resumable", it.resumable)
                        put("status", it.status.name)
                        put("pub", it.publicSaved)
                        put("seg", JSONArray(it.segDone))
                    }
                )
            }
            store.writeText(arr.toString())
        }
    }

    private fun load() {
        runCatching {
            if (!store.exists()) return
            val arr = JSONArray(store.readText())
            _items.value = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val seg = o.getJSONArray("seg")
                val st = Status.valueOf(o.getString("status"))
                DownloadItem(
                    id = o.getLong("id"),
                    url = o.getString("url"),
                    fileName = o.getString("name"),
                    total = o.getLong("total"),
                    downloaded = o.getLong("done"),
                    resumable = o.getBoolean("resumable"),
                    segDone = List(seg.length()) { seg.getLong(it) },
                    status = if (st == Status.RUNNING || st == Status.QUEUED) Status.PAUSED else st,
                    publicSaved = o.optBoolean("pub", false),
                )
            }
        }
    }
}
