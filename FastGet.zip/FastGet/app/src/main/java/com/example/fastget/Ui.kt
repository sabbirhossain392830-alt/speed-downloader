package com.example.fastget

import android.widget.Toast
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FastGetApp(shared: MutableState<String?>) {
    val list by Downloader.items.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(shared.value) { if (shared.value != null) showAdd = true }

    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("FastGet") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add download")
                }
            },
        ) { pad ->
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                    Text("Tap + to add a download link")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.padding(pad),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(list, key = { it.id }) { DownloadCard(it) }
                }
            }
        }
        if (showAdd) {
            AddDialog(initial = shared.value ?: "") {
                showAdd = false
                shared.value = null
            }
        }
    }
}

@Composable
fun DownloadCard(d: DownloadItem) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(
                d.fileName.ifEmpty { d.url },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(8.dp))

            if (d.status != Status.COMPLETED) {
                if (d.total > 0) {
                    LinearProgressIndicator(
                        progress = { (d.downloaded.toFloat() / d.total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else if (d.status == Status.RUNNING) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }

            Text(infoLine(d), style = MaterialTheme.typography.bodySmall)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                when (d.status) {
                    Status.RUNNING -> IconButton(onClick = { Downloader.pause(d.id) }) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause")
                    }
                    Status.COMPLETED -> {}
                    else -> IconButton(onClick = { Downloader.start(d.id) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Resume")
                    }
                }
                IconButton(onClick = { Downloader.remove(d.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove")
                }
            }
        }
    }
}

private fun infoLine(d: DownloadItem): String = when (d.status) {
    Status.COMPLETED ->
        "Done · ${fmtBytes(d.total)}" +
            if (d.publicSaved) " · Saved in Downloads/FastGet" else " · App storage"
    Status.FAILED -> "Failed: ${d.error ?: "unknown error"}"
    else -> {
        val pct = if (d.total > 0) "${(d.downloaded * 100 / d.total)}% · " else ""
        val size = "${fmtBytes(d.downloaded)} / ${fmtBytes(d.total)}"
        val tail = if (d.status == Status.RUNNING) " · ${fmtBytes(d.speed)}/s" else ""
        val state = when (d.status) {
            Status.PAUSED -> "Paused · "
            Status.QUEUED -> "Queued · "
            else -> ""
        }
        state + pct + size + tail
    }
}

@Composable
fun AddDialog(initial: String, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add download") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Link (http / https)") },
                    modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { clip.getText()?.text?.let { text = it.trim() } }) {
                    Text("Paste from clipboard")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (Downloader.add(text)) onDismiss()
                else Toast.makeText(ctx, "Invalid link", Toast.LENGTH_SHORT).show()
            }) { Text("Download") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
